import random
import os
import time

def print_board(board): 
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"\033[1;0mPlayer is \033[1;33m{player}\033[0m, Bot is \033[1;33m{bot}\033")
    for i, cell in enumerate(board):
        if cell == "X" or cell == "O":
            print(f"\033[1;30;47m {cell} \033[0m", end="")
        else:
            print(f"\033[1;33;42m {i+1} \033[0m", end="")
        if (i+1) % 3 == 0:
            print("")
            if i < 8:
                print("---+---+---")


board = ["1", "2", "3", "4", "5", "6", "7", "8", "9"]

bot = random.choice(["X", "O"])
if bot == "X":
    player = "O"
else:
    player = "X"


def check_winner(board):
    if (board[0] == board[1] == board[2] and board[0] != " ") or \
    (board[3] == board[4] == board[5] and board[3] != " ") or \
    (board[6] == board[7] == board[8] and board[6] != " ") or \
    (board[0] == board[3] == board[6] and board[0] != " ") or \
    (board[1] == board[4] == board[7] and board[1] != " ") or \
    (board[2] == board[5] == board[8] and board[2] != " ") or \
    (board[0] == board[4] == board[8] and board[0] != " ") or \
    (board[2] == board[4] == board[6] and board[2] != " "):
        return True
    return False

def playwithtoes():
    board = [" " for x in range(9)]
    turn = random.choice([player, bot])
    os.system('cls' if os.name == 'nt' else 'clear')
    
    if turn == bot:
        print(f"\033[1;32mBot goes first\033[0m")
    else:
        print(f"\033[1;32mPlayer goes first\033[0m")
    input("Press enter to continue...") 
    while True:
            if " " not in board:
                return -1
            else: 
                print_board(board)
                if turn == player:
                    try:
                        move = int(input("Enter your move (1-9): "))
                        if move > 9 or move < 1:
                            raise ValueError
                    except:
                        print("\033[1;31mInvalid move\033[0m")
                        time.sleep(.15)
                        continue
                    if board[move-1] == " ":
                        board[move-1] = player
                        if check_winner(board):
                            print_board(board)
                            return True
                        else:
                            turn = bot
                    else:
                        print("\033[1;31mInvalid move\033[0m")
                        time.sleep(.15)
                else:
                    move = random.randint(0,8)
                    if board[move] == " ":
                        board[move] = bot
                        if check_winner(board):
                            print_board(board)
                            return False
                        else:
                            turn = player

player = "X"
bot = "O"
