import sounddevice as sd
import soundfile as sf

base = "soundtrack/"
tracks = {
        "casual":base+"gen1.wav",
        "casual2":base+"gen2.wav",
        "story":base+"peculiar.wav",
        "boss":base+"boss.wav",
        "suman":base+"final.wav",
        "tictactoe":base+"toes.wav"
    }

def playsound(track):   
    filename = tracks[track]
    data, fs = sf.read(filename, dtype='float32')  
    sd.play(data, fs)

def stopsound():
    sd.stop()
