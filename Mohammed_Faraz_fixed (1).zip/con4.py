import os
import time
import numpy as np

xcord, ycord = os.get_terminal_size()
ANIMATION_DELAY = .1

def print_lines(*lines):
    for line in lines:
        print(line.center(xcord))

class ConnectFour:
    def __init__(self, height=6, width=7):
        self._to_bin = 2 ** np.arange(height * (width + 2), dtype=object)

        self.height, self.width = height, min(width, 35)
        self.labels = "1234567"[:self.width]
        self.board = np.zeros((self.height, self.width + 2), dtype=int)

    @property
    def current_player(self):
        return np.count_nonzero(self.board) % 2 + 1

    def print_board(self):
        os.system('cls' if os.name == 'nt' else 'clear')

        top = f"Player: ● | Bot: ○"
        head = f"╷{'╷'.join(self.labels)}╷"
        sides = (f"│{'│'.join(' ●○'[value] for value in row[:-2])}│" for row in self.board[::-1])
        bottom = f"╰{'─┴' * (self.width - 1)}─╯"

        print("\n" * ((ycord - self.height - 5) // 2)) 
        print_lines(top, head, *sides, bottom)

    def is_valid_move(self, move: str) -> bool:
        if move == 'q':
            return True

        if not (len(move) == 1 and move in self.labels):
            print_lines("Please input a valid column!")
            return False

        column = self.labels.find(move)
        if np.count_nonzero(self.board[:, column]) < self.height:
            return True

        print_lines("No moves possible in that column!")
        return False

    def get_valid_move(self) -> str:
        if self.current_player == 1:
            player = "○"
            while True:
                print_lines(f"●'s move, enter column or 'q' to quit:\n")
                move = input("".center(xcord // 2)).lower()
                if self.is_valid_move(move):
                    return move
        else:
            player = "●"
            random_column = self.labels[random.randint(0, self.width-1)]
            print_lines(f"{player}'s move, generated random column:\n")
            print_lines(random_column)
            return random_column

    def play_move(self, column: int):
        player = self.current_player
        final_row = np.count_nonzero(self.board[:, column])
        board = self.board

        for row in range(self.height - 1, final_row, -1):
            board[row, column] = player
            self.print_board()
            board[row, column] = 0
            time.sleep(ANIMATION_DELAY)

        board[final_row, column] = player

    def is_winner(self, player):
        key = (self.board == player).flatten() @ self._to_bin
        w = self.width + 2
        return any(
            key
            & key >> offset
            & key >> 2 * offset
            & key >> 3 * offset
            for offset in (1, w - 1, w, w + 1)
        )

    def run(self):
        for _ in range(self.width * self.height):
            player = self.current_player

            self.print_board()

            if player == 1:
                move = self.get_valid_move()
            else:
                valid_columns = [i for i in range(self.width) if np.count_nonzero(self.board[:, i]) < self.height]
                move = self.labels[np.random.choice(valid_columns)]

            if move == "q":
                break
            column = self.labels.find(move)
            self.play_move(column)

            if self.is_winner(player):
                self.print_board()
                print_lines(f"{'●○'[player - 1]} wins!")
                time.sleep(2)
                if '●○'[player - 1] == '●':
                    return True
                else:
                    return False
        else:
            self.print_board()
            print_lines("It's a draw!")
            print("suman2001: a draw huh? we'll go again")

def run():
    return(ConnectFour().run())