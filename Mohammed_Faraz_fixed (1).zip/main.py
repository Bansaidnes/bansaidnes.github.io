import rps, tictactoe, audio, con4
import time, random, os
from colorama import Fore

def sPrint(text, delay):
    time.sleep(delay)
    print(Fore.CYAN + text)

def cPrint(text, delay, color):
    time.sleep(delay)
    print(color+text)

os.system("cls")
print(Fore.RED+"This game is best played with the audio enabled"+Fore.WHITE)
audio.playsound("casual")

#common var
playerName = input("Welcome!\nPlease name your character: ")
yeses = {"y", "yes","", "YES", "Yes", "Y", "YEs", "yeS", "yEs"}
inventory = {}
Playerhealth = 100

InitialDial = {
        f"???: Wake up! {playerName} wake up!": 2.5,
        f"???: {playerName} are you alright?": 2.5,
        f"{playerName}: Who are you?": 2.5,
        "???: Huh?? im your sister, Megumi": 2.5,
        f"{playerName}: I do not recall having a sister": 1,
        f"{playerName}: Infact, i dont remember anything...": 1,
        f"{playerName}: What happened to me?": 4,
        "Megumi: oh its a long story..": 2
}

os.system("cls")
for key in InitialDial:
    sPrint(key, InitialDial[key])
input("\npress enter to continue...\n")

LongStory = {
    "Megumi: Around a week ago, we found you unconscious near the local farm": 4,
    "Megumi: Bystanders say they saw a dark force of some sort rush out of your body": 4,
    "Megumi: Incidents like this have been popping up around town since then": 4,
    "Megumi: Seemingly, all this dark energy was flowing towards the abandoned castle in the woods": 4,
    "Megumi: Would you like to pay the castle a visit?": 3
}

audio.playsound("story")
for key in LongStory:
    sPrint(key, LongStory[key])
goCastle = input("\ntrust the woman and head to the castle?(Y/n): ").lower()

if(yeses.__contains__(goCastle)):
    enterCastle = input("Megumi: Ah we're finally here, wanna head inside and figure out what happened to your memories?(Y/n): ")
    if(yeses.__contains__(enterCastle)):
        print("You walk into the castle..")
    else:
        sPrint("\nMegumi: Guess we should look around for items then", 2)
        print("Megumi is searching for items...")
        sPrint("\nMegumi: Oooh! I found a sword! Check it out", 5)
        print("The sword has been added to your inventory")
        inventory[0] = "iron sword"
    
    print("\nYou feel chills run up your spine as you enter the castle")
    input("\npress enter to continue...\n")

    mohash = {
        "???: Who goes there": 3,
        "???: You there! You dare disturb mohash's slumber?": 2.5,
        "mohash: There's only one way you're getting out of this...": 2.5,
        "mohash: And that is... by beating me in rock paper scissors!": 4,
        f"{playerName}: rock paper scissors? seems easy enough": 2,
        "Megumi: Game on!": 3
    }

    os.system("cls")
    audio.playsound("boss")
    for key in mohash:
        cPrint(key, mohash[key], Fore.RED)
    rpsWin = rps.playrps()
    count = 0
    while rpsWin == -1:
        if count == 0:
            print("mohash: a draw huh? let's go again!")
            time.sleep(3)
        count += 1
        rpsWin = rps.playrps()
    if(rpsWin):
        os.system("cls") 
        print(Fore.WHITE)

        postwinhash = {
            "Megumi: Any question you said?": 2,
            "mohash: Indeed": 2,
            f"{playerName}: There have been reports of people losing all their memories and falling into comas, know anything about it?": 2,
            "mohash: well..": 2,
            "mohash: my boss....": 4,
            "mohash: has been collecting memories....": 3,
            "mohash: but if you wish to defeat him, then you must reach to the top!": 2,
            "mohash: btw, there may or may not be another guard just like me": 2
        }

        os.system("cls")
        audio.playsound("casual2")
        for key in postwinhash:
            sPrint(key, postwinhash[key])
        input("\npress enter to continue....\n")
        
        os.system("cls")
        print(f"Megumi: well {playerName}, you heard him, let's continue!")
        print("You and megumi look for the staircase...\n")
        time.sleep(4)
        seaweed = {
            "???: I sense you fools": 2.5,
            "???: SHOW YOURSELVES!": 2,
            "???: OR PREPARE TO DIE": 2,
            "Megumi: Woah there, Slow down... we're willing to hear you out": 4,
            "???: I heard that you defeated my brother...": 2,
            "???: But I, seaweed, remain undefeated!": 2,
            "seaweed: I challenge you to a game of tictactoe!": 2,
            f"{playerName}: tictactoe? you've got to be kidding me": 2,
            "seaweed: Enough mockery, let's get started": 2
        }
        
        os.system("cls")
        audio.playsound("boss")
        for key in seaweed:
            cPrint(key, seaweed[key], Fore.RED)
        toeWin = tictactoe.playwithtoes()
        count = 0
        while toeWin == -1:
            if count == 0:
                print("seaweed: a draw huh? let's go again!")
                time.sleep(3)
            count += 1
            toeWin = tictactoe.playwithtoes()
        os.system("cls")
        audio.playsound("story")
        if(toeWin):
            postwinsea = {
                "seaweed: huh, perhaps i can be defeated after all": 2,
                "seaweed: the boss is just up this staircase": 2,
                "seaweed: but beware, he is the most powerful out of all of us":2,
                "seaweed: good luck...": 4,
                f"Megumi: did you hear that {playerName}? guess you're going to get your memories back!": 4
            }
            for key in postwinsea:
                sPrint(key, postwinsea[key])
            
            input("\npress enter to meet the boss...\n")
            os.system("cls")
            audio.playsound("boss")
            suman2001 = {
                "????: So you defeated my little minions huh?":3,
                "????: Well I must say, im quite impressed":3,
                "????: But this will be the place of your demise": 3,
                "????: Without further adieu, let's get into my minigame, connect 4!": 3
            }
            audio.playsound("boss")
            for key in suman2001: 
                cPrint(key, suman2001[key], Fore.RED)
            con4win = con4.run()
            os.system("cls")
            if(con4win):
                postsuman2001 = {
                    "????: You actually did it...":4,
                    "????: I'm surprised": 2,
                    "????: It's no longer time for fun and games":3,
                    "????: I suman2001, challenge you to a REAL battle....":4
                }
                audio.playsound("story")
                for key in postsuman2001:
                    sPrint(key, postsuman2001[key])
                audio.playsound("suman")
                sumanHealth = 100
                print("sumaan2001: to damage me, you must roll a number higher than me from a range of 1-6")
                Pspaces = "       "
                Sspaces = "      "
                while(sumanHealth > 0):
                    os.system("cls")
                    if Playerhealth <= 0:
                        print("You choked at the final part, congratulations. The END :C")
                        exit(0)
                    if Playerhealth < 10:
                            Pspaces = "         "
                    elif sumanHealth < 10:
                        Sspaces = "        "
                    elif Playerhealth < 100:
                        Pspaces = "        "
                    elif sumanHealth < 100:
                        Sspaces = "       "
                    print(f"""
╭────────────────────╮
│ Suman HP: {sumanHealth}{Sspaces}│        
│ Your HP: {Playerhealth}{Pspaces}│
╰────────────────────╯""")
                    input("press enter to roll")
                    sumanR = random.randint(1, 6) 
                    playerR = random.randint(1, 6)
                    print(f"You rolled a {playerR}, Suman rolled a {sumanR}")
                    Pdmg = random.randint(6,10)
                    Sdmg = random.randint(1, 7)
                    if inventory:
                        if(inventory[0] == "iron sword"):
                            bonus = random.randint(1, 3)
                            Pdmg += bonus
                            if playerR > sumanR:
                                print(f"\nYour iron sword allows you to deal {bonus} extra damage!\n")
                    if playerR > sumanR:
                        print(f"you dealt {Pdmg} damage!")
                        sumanHealth -= Pdmg
                    elif sumanR > playerR:
                        print(f"Suman damaged you for {Sdmg}hp")
                        Playerhealth -= Sdmg
                    elif sumanR == playerR:
                        print("no one took damage!")
                    time.sleep(3.5)
                finalDial = {
                    "suman2001: IMPOSSIBLE....":4,
                    "suman2001: IM NO MERE MORTAL....":4,
                    f"Megumi: {playerName} look! There's some strange dark energy coming out of him":2,
                    f"Megumi: {playerName} are you ok?": 2,
                    f"{playerName}: I... remember....":5,
                    f"{playerName}: I remember... everything...":4,
                    f"Megumi: What a ride! Im glad you're back {playerName}!":2
                }
                os.system("cls")
                for key in finalDial:
                    cPrint(key, finalDial[key], Fore.GREEN)
                input("THE END >:D | YOU WIN")
            else:
                print("You were publicly executed using a guillotine. The END :C")
        else:
            print("You croaked. The END :C")
    else:
        print(Fore.RED+"You lost and were executed. The end :C")
else:
    print(Fore.RED+"\nYou attempt to flee from the woman but fall into a ditch and die in the process. The END :C")
