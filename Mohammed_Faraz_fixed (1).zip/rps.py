import random, os, time

rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'    ____)____
           ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
      __________)
      (____)
---.__(___)
'''

options = {
    1: rock,
    2: paper,
    3: scissors
}

results = {
    (1, 1): -1,
    (1, 2): False,
    (1, 3): True,
    (2, 1): True,
    (2, 2): -1,
    (2, 3): False,
    (3, 1): False,
    (3, 2): True,
    (3, 3): -1
}

def playrps(): 
    os.system('cls' if os.name == 'nt' else 'clear')
    pC = False
    while(pC == False):
        try:
            player = int(input("Enter your choice [1 - Rock] [2 - Paper] [3 - Scissors] "))
            pC = True
        except KeyError:
            print("invalid move, try again") 
            continue
    bot = random.randint(1, 3)

    print(f"{options[player]} vs {options[bot]}")

    time.sleep(3)

    result = results[(player, bot)]
    return(result)